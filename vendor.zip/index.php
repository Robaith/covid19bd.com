<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="title" content="covid19bd">
  <meta name="description" content="A  site for corona virus live updates in Bangladesh">
  <meta name="keywords" content="Covid-19, Corona, Virus, Corona Bangladesh, Corona Virus Bangladesh, Corona update BD, Corona BD , Corona Hotline BD">
  <meta name="robots" content="index, follow">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="language" content="English">
  <meta property="og:type" content="website">
  <meta property="og:url" content="http://covid19bd.com">
  <meta property="og:title" content="covid19bd">
  <meta property="og:description" content="A  site for corona virus live updates in Bangladesh">
  <meta property="og:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">


  <title>Corona Live Update</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
 <?php include 'navigation.php';?>
  <!-- Page Content -->
  <div class="container">

        <!-- Jumbotron Header -->
    <header class="jumbotron my-4">
      <h3>IEDCR Hotline : </h3>
      <p class="lead">01401184551, 01401184554, 01401184555, 01401184556, 01401184559, 01401184560, 01401184563, 01401184568, 01927711784, 01927711785, 01937000011, 01937110011</p>
      <h3>DGHS Hotline : </h3>
      <p>16263</p>
      
    </header>

    <!-- Page Features -->
    <div class="row text-center">

      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary">Total Cases</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="tc"></h4>
            <!-- <p class="card-text">Lorem ipsum dolor .</p> -->
          </div>
          
        </div>
      </div>

      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary">Active Cases</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="ac"></h4>
            <!-- <p class="card-text">Lorem ipsum dolor .</p> -->
          </div>
          
        </div>
      </div>
      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary" style="background: green" >Total Recovered</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="tr"></h4>
           <!--  <p class="card-text">Lorem ipsum dolor .</p> -->
          </div>
          
        </div>
      </div>
      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary" style="background: red">Total Deaths</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="td"></h4>
            <!-- <p class="card-text">Lorem ipsum dolor .</p> -->
          </div>
          
        </div>
      </div>
      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary">New Cases Today</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="nc"></h4>
           <!--  <p class="card-text">Lorem ipsum dolor .</p> -->
          </div>
          
        </div>
      </div>
      <div class="col-lg-6 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-header">
            <a href="#" class="btn btn-primary" style="background: red">New Deaths Today</a>
          </div>
          
          <div class="card-body">
            <h4 class="card-title" id="nd"></h4>
            <!-- <p class="card-text"> .</p> -->
          </div>
          
        </div>
      </div>


    </div>
    <!-- /.row -->


  </div>
  <!-- /.container -->
 
   <?php include 'footer.php';?>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript">
$(document).ready(function() {
    // your setTimeout function goes in here.

    function doajax(){
    	$.ajax({
  url: 'https://thevirustracker.com/free-api?countryTotal=BD',
  dataType: 'json',
  success: function(data) {

    var obj = data;



    document.getElementById("tc").innerHTML = obj.countrydata[0].total_cases;
    document.getElementById("tr").innerHTML = obj.countrydata[0].total_recovered;
    document.getElementById("td").innerHTML = obj.countrydata[0].total_deaths;
    document.getElementById("nc").innerHTML = obj.countrydata[0].total_new_cases_today;
    document.getElementById("nd").innerHTML = obj.countrydata[0].total_new_deaths_today;
    document.getElementById("ac").innerHTML = obj.countrydata[0].total_active_cases;
// var x='';
//     //var k= reverse();
//     for (const i in obj.countrynewsitems.reverse()[0]) {
//   x += obj.countrynewsitems.reverse()[0][i].title + "<br>";
   
  
// }
// document.getElementById("demo").innerHTML = x;



  }
});



           
    };

     doajax();

     setInterval(doajax,5000);
});
  </script>


</body>

</html>
