<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php';?>
</head>
<body>
	<?php include 'navigation.php';?>
	<iframe src="https://infographics.channelnewsasia.com/covid-19/map.html" height="1000" width="100%"></iframe>

</body>
</html>